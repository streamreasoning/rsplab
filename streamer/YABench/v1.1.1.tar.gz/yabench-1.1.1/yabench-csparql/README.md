# c-sparql-engine

## usage after jar has been built
    java -jar ./target/c-sparql-engine-0.0.1-SNAPSHOT-jar-with-dependencies.jar -query ./src/main/resources/queries/q1 -dest tbd -source ../streams/TestQ1 -wsize 10 -wslide 1