# Stream generator

## Stream Generator #1

The following command generates a stream #1 with the default parameters:
```
java -jar stream-generator-1.0-SNAPSHOT-jar-with-dependencies.jar -dest streams/ -name SG1
```
