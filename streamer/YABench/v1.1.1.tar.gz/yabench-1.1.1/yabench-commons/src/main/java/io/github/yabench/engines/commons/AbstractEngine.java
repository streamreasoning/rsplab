package io.github.yabench.engines.commons;

public abstract  class AbstractEngine implements Engine {
    
}
