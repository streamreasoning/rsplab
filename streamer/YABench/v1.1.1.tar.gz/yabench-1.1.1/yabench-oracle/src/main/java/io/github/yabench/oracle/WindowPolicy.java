package io.github.yabench.oracle;

public enum WindowPolicy {

    ONWINDOWCLOSE, ONCONTENTCHANGE
}
